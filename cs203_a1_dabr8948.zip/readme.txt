To run Brute Force, run NQueens with the run arguments: "brute n" where n is the number for n
To run Iterative Repair, run NQueens with the run arguments: "iterative n" where n is the number for n